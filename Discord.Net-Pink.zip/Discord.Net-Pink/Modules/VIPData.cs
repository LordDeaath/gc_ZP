﻿using Discord.Commands;
using Discord.WebSocket;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace DNet.Modules
{
    public class VIPData : ModuleBase<SocketCommandContext>
    {
        [Command("listvip")]
        public async Task listvipAsync()
        {
            string SrvNam = null;
            string cid = Convert.ToString(Context.Channel.Id);
            if (cid != "749606002961285130" && cid != "880091872763203635")
            {
                await ReplyAsync(Context.Message.Author.Mention + " Please use this command in the bot channel.");
                return;
            }
            string SrvLocation = null, Txt = null, Txtformat = null;
            SrvLocation = "/home/ogp_agent/OGP_User_Files/Zombi/2022/cstrike/addons/amxmodx/configs/vips.ini";
            SrvNam = "Zombie Plague";
            List<string> found = new List<string>();
            string line;
            using (StreamReader file = new StreamReader(SrvLocation))
            {
                while ((line = file.ReadLine()) != null)
                {
                    found.Add(line);
                }
            }
            for (int i = 0; i < found.Count; i++)
            {
                Txtformat = found[i];
                if (Txtformat.StartsWith(";"))
                    continue;
                Txtformat = Txtformat.Replace("\"STEAM", "ID: STEAM");
                Txtformat = Txtformat.Replace("\"VALVE", "ID: VALVE");
                Txtformat = Txtformat.Replace("\" \"\" \"ae\" \"ce\";", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"ae\" \"ce\" ;", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"ade\" \"ce\";", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"ade\" \"ce\" ;", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"bd\" \"ce\" ;", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"bd\" \"ce\";", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"bd\" \"ce\"; ", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"d\" \"ce\";", " | ");
                Txtformat = Txtformat.Replace("\" \"\" \"d\" \"ce\" ;", " | ");
                Txt += Txtformat + "\n";
            }
            await ReplyAsync("List of vips for server: " + SrvNam + "```" + Txt + "```");

        }
        [Command("rvip")]
        public async Task rVIP(string nick = null, SocketGuildUser socketGuildUser = null)
        {
            string cid = Convert.ToString(Context.Channel.Id);
            if (cid != "749606002961285130" && cid != "880091872763203635")
            {
                await ReplyAsync(Context.Message.Author.Mention + " Please use this command in the bot channel.");
                return;
            }
            string dBHost, dBPort, dBUser, dBPass, dB, dbConnection, dBConWithBase, ErrorLog;
            dBHost = ConfigurationManager.AppSettings.Get("MySql_Host");
            dBPort = ConfigurationManager.AppSettings.Get("MySql_Port");
            dBUser = ConfigurationManager.AppSettings.Get("MySql_User");
            dBPass = ConfigurationManager.AppSettings.Get("MySql_Password");
            dB = ConfigurationManager.AppSettings.Get("MySql_Database");
            dbConnection = "Server=" + dBHost + ";Port=" + dBPort + ";Uid=" + dBUser + ";Pwd=" + dBPass;
            string Adminid = Convert.ToString(Context.Message.Author.Id);
            string AdminQuery = "SELECT * FROM " + dB + ".Admins WHERE AdminID = '" + Adminid + "';";
            using var con = new MySqlConnection(dbConnection);
            con.Open();
            using var cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = AdminQuery;
            MySqlDataReader Reader;
            cmd.ExecuteNonQuery();
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (!Reader.HasRows)
                {
                    await ReplyAsync("```You are not an admin, sorry.```");
                    return;
                }
            }
            string SrvLocation = "/home/ogp_agent/OGP_User_Files/Zombi/2022/cstrike/addons/amxmodx/configs/vips.ini";
            if (nick == null)
            {
                await ReplyAsync("```Please add nick.```");
                return;
            }
            List<string> found = new List<string>();
            string line;
            using (StreamReader file = new StreamReader(SrvLocation))
            {
                while ((line = file.ReadLine()) != null)
                {
                    if (line.Contains(nick))
                        found.Add(line);
                }
            }
            string Txt = File.ReadAllText(SrvLocation);
            Txt = Txt.Replace(found[0], "");
            File.WriteAllText(SrvLocation, Txt);
            await ReplyAsync("VIP found and removed!");
            await listvipAsync();
        }
        [Command("vipadd")]
        public async Task addvip(string SteamID = null, string acc = null, string nick = null, string expriedate = null, SocketGuildUser socketGuildUser = null)
        {
            string cid = Convert.ToString(Context.Channel.Id);
            if (cid != "749606002961285130" && cid != "880091872763203635")
            {
                await ReplyAsync(Context.Message.Author.Mention + " Please use this command in the bot channel.");
                return;
            }
            string Format = null, rn = null, Txt = null;
            string dBHost, dBPort, dBUser, dBPass, dB, dbConnection, dBConWithBase, ErrorLog;
            dBHost = ConfigurationManager.AppSettings.Get("MySql_Host");
            dBPort = ConfigurationManager.AppSettings.Get("MySql_Port");
            dBUser = ConfigurationManager.AppSettings.Get("MySql_User");
            dBPass = ConfigurationManager.AppSettings.Get("MySql_Password");
            dB = ConfigurationManager.AppSettings.Get("MySql_Database");
            dbConnection = "Server=" + dBHost + ";Port=" + dBPort + ";Uid=" + dBUser + ";Pwd=" + dBPass;
            string Adminid = Convert.ToString(Context.Message.Author.Id);
            string AdminQuery = "SELECT * FROM " + dB + ".Admins WHERE AdminID = '" + Adminid + "';";
            using var con = new MySqlConnection(dbConnection);
            con.Open();
            using var cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = AdminQuery;
            MySqlDataReader Reader;
            cmd.ExecuteNonQuery();
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (!Reader.HasRows)
                {
                    await ReplyAsync("```You are not an admin, sorry.```");
                    return;
                }
            }
            string SrvLocation = "/home/ogp_agent/OGP_User_Files/Zombi/2022/cstrike/addons/amxmodx/configs/vips.ini";
            if (SteamID == null)
            {
                await ReplyAsync("```Please add steamid.```");
                return;
            }
            if (acc == null)
            {
                await ReplyAsync("```Please add access (a|b|c|d|e).```");
                return;
            }
            if (nick == null)
            {
                await ReplyAsync("```Please add nick.```");
                return;
            }
            if (expriedate != null)
            {
                int days = Convert.ToInt32(expriedate);
                TimeSpan time = TimeSpan.FromDays(days);
                DateTime rNow = DateTime.Now;
                DateTime combined = rNow.Add(time);
                rn = combined.ToString("|M+d-yyyy");
                rn = rn.Replace("|", "m");
                rn = rn.Replace("+", "d");
                rn = rn.Replace("-", "y");
            }
            if (acc.Contains("d"))
                nick = nick + " (Premium)";
            Format = "\"" + SteamID + "\" " + "\"\" " + "\"" + acc + "\" " + "\"ce\";" + nick + " " + rn;
            Txt = File.ReadAllText(SrvLocation);
            Txt += "\n" + Format;
            File.WriteAllText(SrvLocation, Txt);
            await ReplyAsync("VIP added!");
            await listvipAsync();
        }
    }
}
