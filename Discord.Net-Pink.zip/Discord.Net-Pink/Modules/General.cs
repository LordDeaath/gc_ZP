﻿using Discord.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNet.Modules
{
    public class General : ModuleBase<SocketCommandContext>
    {
        string Info = "```diff\n" + "!apinfo steamid -> shows ammopacks for a steamid.\n" +
                "!xpinfo steamid -> shows levels for a steamid.\n" +
                "!viplist server -> lists all vips in Zombie Plague server.\n" +
                "-[Admin Only Commands Below]\n" +
                "-!apadd steamid ammo -> adds AP or -AP to a steamid\n" +
                "-!xpadd steamid xp -> adds XP or -XP to a steamid\n" +
                "-(player must be offline in the server for AP/XP Manuplation).\n" +
                "-!vipadd steamid acc name days\n" +
                "-  acc: ade for full vip | bd for Mini VIP\n" +
                "-       Example: vipadd STEAM_0:0_123 ade Lord 31\n" +
                "-!rvip server nick -> removes a vip\n" +
                "-       Example: !rvip Lord```";
        [Command("info")]
        [Alias("help")]
        public async Task PingAsync()
        {
            await Context.Channel.TriggerTypingAsync();
            await ReplyAsync(Context.Message.Author.Mention + Info);
        }
    }
}
