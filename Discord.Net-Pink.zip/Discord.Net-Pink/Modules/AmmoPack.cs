﻿using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DNet.Modules
{
    public class AmmoPack : ModuleBase<SocketCommandContext>
    {
        [Command("apinfo")]
        public async Task apinfoAnsyc(string SteamID = null, SocketGuildUser socketGuildUser = null)
        {
            string cid = Convert.ToString(Context.Channel.Id);
            if (cid != "749606002961285130" && cid != "880091872763203635")
            {
                await ReplyAsync(Context.Message.Author.Mention + " Please use this command in the bot channel.");
                return;
            }
            string dBHost, dBPort, dBUser, dBPass, dB, dbConnection, dBConWithBase, ErrorLog;
            dBHost = ConfigurationManager.AppSettings.Get("MySql_Host");
            dBPort = ConfigurationManager.AppSettings.Get("MySql_Port");
            dBUser = ConfigurationManager.AppSettings.Get("MySql_User");
            dBPass = ConfigurationManager.AppSettings.Get("MySql_Password");
            dB = ConfigurationManager.AppSettings.Get("MySql_Database");
            dbConnection = "Server=" + dBHost + ";Port=" + dBPort + ";Uid=" + dBUser + ";Pwd=" + dBPass;
            using var con = new MySqlConnection(dbConnection);
            con.Open();
            using var cmd = new MySqlCommand();
            cmd.Connection = con;
            MySqlDataReader Reader;
            string id, ammo, nick;
            string UserID = Convert.ToString(Context.Message.Author.Id);
            string Query = "SELECT * FROM " + dB + ".zp_bank WHERE auth = '" + SteamID + "';";
            if (SteamID == null)
            {
                await ReplyAsync(Context.Message.Author.Mention + "```Enter SteamID to show data.```");
                return;
            }
            cmd.CommandText = Query;
            cmd.ExecuteNonQuery();
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (Reader.HasRows)
                {
                    id = Reader.GetString(0);
                    ammo = Reader.GetString(2);
                    nick = Reader.GetString(4);
                    await ReplyAsync(Context.Message.Author.Mention + "```Player: " + nick + " (ID: " + id + ") has " + ammo + "```");
                }
                else await ReplyAsync(Context.Message.Author.Mention + "```Player info not found```");
            }
        }
        [Command("apadd")]
        public async Task addAPAsync(string SteamID = null, string amount = null, SocketGuildUser socketGuildUser = null)
        {
            string cid = Convert.ToString(Context.Channel.Id);
            if (cid != "749606002961285130" && cid != "880091872763203635")
            {
                await ReplyAsync(Context.Message.Author.Mention + " Please use this command in the bot channel.");
                return;
            }
            string dBHost, dBPort, dBUser, dBPass, dB, dbConnection, dBConWithBase, ErrorLog;
            dBHost = ConfigurationManager.AppSettings.Get("MySql_Host");
            dBPort = ConfigurationManager.AppSettings.Get("MySql_Port");
            dBUser = ConfigurationManager.AppSettings.Get("MySql_User");
            dBPass = ConfigurationManager.AppSettings.Get("MySql_Password");
            dB = ConfigurationManager.AppSettings.Get("MySql_Database");
            dbConnection = "Server=" + dBHost + ";Port=" + dBPort + ";Uid=" + dBUser + ";Pwd=" + dBPass;
            await ReplyAsync("```Processing your request...```");
            string Adminid = Convert.ToString(Context.Message.Author.Id);
            string AdminQuery = "SELECT * FROM " + dB + ".Admins WHERE AdminID = '" + Adminid + "';";
            using var con = new MySqlConnection(dbConnection);
            con.Open();
            using var cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = AdminQuery;
            MySqlDataReader Reader;
            cmd.ExecuteNonQuery();
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (!Reader.HasRows)
                {
                    await ReplyAsync("```You are not an admin, sorry.```");
                    return;
                }
            }
            int int_amount;
            string id, ammo, nick;
            string UserID = Convert.ToString(Context.Message.Author.Id);
            string dataQuery = "SELECT * FROM " + dB + ".zp_bank WHERE auth = '" + SteamID + "';";
            string Query = "UPDATE " + dB + ".zp_bank SET amount = amount + " + amount + " WHERE auth = '" + SteamID + "';";
            if (SteamID == null)
            {
                await ReplyAsync(Context.Message.Author.Mention + "```Enter SteamID to enter data.```");
                return;
            }
            int_amount = Convert.ToInt32(amount);
            if (int_amount == 0)
            {
                await ReplyAsync(Context.Message.Author.Mention + "```Enter ammopacks please.```");
                return;
            }
            cmd.CommandText = dataQuery;
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (Reader.HasRows)
                {
                    await ReplyAsync("```Found player...adding ammo!```");
                }
                else
                {
                    await ReplyAsync(Context.Message.Author.Mention + "```Player info not found.```");
                    return;
                }
            }
            cmd.CommandText = Query;
            cmd.ExecuteNonQuery();
            cmd.CommandText = dataQuery;
            using (Reader = cmd.ExecuteReader())
            {
                Reader.Read();
                if (Reader.HasRows)
                {
                    id = Reader.GetString(0);
                    ammo = Reader.GetString(2);
                    nick = Reader.GetString(4);
                    await ReplyAsync("```Player: " + nick + " (ID: " + id + ") updated to " + ammo + "```");
                }
                else await ReplyAsync(Context.Message.Author.Mention + "```Player info not found```");
            }
        }
    }

}
